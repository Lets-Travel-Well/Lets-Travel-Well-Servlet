package com.ssafy.ltw.global.util.db;

public interface DBProperties {
    String getDriver();
    String getURL();
    String getDBId();
    String getDBPwd();
}
