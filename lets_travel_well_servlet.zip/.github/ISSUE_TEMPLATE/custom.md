---
name: Custom issue template
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

### 🗄️ 종류

issue 종류를 선택하세요

- [ ] Code Review
- [ ] New Feature
- [ ] Remove Feature
- [ ] Change Logic
- [ ] Bug Fix
- [ ] Setup
## 🔍Description

> description

## 📝Todo

- [ ] todo1
- [ ] todo2
- [ ] todo3
- [ ] todo4
